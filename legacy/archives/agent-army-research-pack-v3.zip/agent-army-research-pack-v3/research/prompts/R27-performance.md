# R27-performance.md

Use the expanded prompt from the v2 pack. This pack adds R00 and the recommended execution order.
